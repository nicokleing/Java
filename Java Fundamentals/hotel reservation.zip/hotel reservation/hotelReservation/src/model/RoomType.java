package model; // or another appropriate package

public enum RoomType {
    SINGLE, DOUBLE
}
