package ui; // Asumiendo que está en el mismo paquete que tus clases de menú.

import java.util.Scanner;

public class HotelApplication {

    public static void main(String[] args) {
        // Iniciar la interfaz de usuario principal.
        MainMenu.displayMainMenu();
    }
}
